import * as SplashScreen from 'expo-splash-screen';
import { useEffect, useState } from 'react';
import { commonStyles } from '../styles/commonStyles';
import { AuthProvider, useAuth } from './context/AuthContext';
import { setupErrorLogging } from '../utils/errorLogger';
import { 
  useFonts,
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  Inter_800ExtraBold,
} from '@expo-google-fonts/inter';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { ThemeProvider } from './context/ThemeContext';
import { Platform, SafeAreaView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import DrawerContent from '../components/DrawerContent';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Drawer } from 'expo-router/drawer';
import { router } from 'expo-router';

const STORAGE_KEY = 'expo-router-store';

SplashScreen.preventAutoHideAsync();

function RootLayoutNav() {
  const { user, isLoading } = useAuth();
  const insets = useSafeAreaInsets();

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        router.replace('/');
      }
    }
  }, [user, isLoading]);

  if (isLoading) {
    return null; // Keep splash screen visible
  }

  if (!user) {
    return (
      <Drawer
        screenOptions={{
          headerShown: false,
          drawerType: 'front',
          swipeEnabled: false,
        }}
      >
        <Drawer.Screen name="index" options={{ drawerItemStyle: { display: 'none' } }} />
        <Drawer.Screen name="login" options={{ drawerItemStyle: { display: 'none' } }} />
        <Drawer.Screen name="signup" options={{ drawerItemStyle: { display: 'none' } }} />
      </Drawer>
    );
  }

  return (
    <Drawer
      drawerContent={(props) => <DrawerContent {...props} />}
      screenOptions={{
        headerShown: false,
        drawerType: 'front',
        swipeEnabled: true,
        drawerStyle: {
          width: 280,
        },
      }}
    >
      <Drawer.Screen name="dashboard" options={{ title: 'Dashboard' }} />
      <Drawer.Screen name="profile" options={{ title: 'Profile' }} />
      <Drawer.Screen name="linked-accounts" options={{ title: 'Linked Accounts' }} />
      <Drawer.Screen name="withdraw" options={{ title: 'Withdraw' }} />
      <Drawer.Screen name="transactions" options={{ title: 'Transactions' }} />
      <Drawer.Screen name="settings" options={{ title: 'Settings' }} />
      <Drawer.Screen name="support" options={{ title: 'Support' }} />
      <Drawer.Screen name="index" options={{ drawerItemStyle: { display: 'none' } }} />
      <Drawer.Screen name="login" options={{ drawerItemStyle: { display: 'none' } }} />
      <Drawer.Screen name="signup" options={{ drawerItemStyle: { display: 'none' } }} />
    </Drawer>
  );
}

export default function RootLayout() {
  const [appIsReady, setAppIsReady] = useState(false);

  const [fontsLoaded] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
    Inter_800ExtraBold,
  });

  useEffect(() => {
    async function prepare() {
      try {
        setupErrorLogging();
      } catch (e) {
        console.warn(e);
      } finally {
        setAppIsReady(true);
      }
    }

    prepare();
  }, []);

  useEffect(() => {
    if (appIsReady && fontsLoaded) {
      SplashScreen.hideAsync();
    }
  }, [appIsReady, fontsLoaded]);

  if (!appIsReady || !fontsLoaded) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <ThemeProvider>
          <AuthProvider>
            <StatusBar style="auto" />
            <RootLayoutNav />
          </AuthProvider>
        </ThemeProvider>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}