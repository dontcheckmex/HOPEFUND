import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from '../components/Icon';
import { useTheme } from './context/ThemeContext';
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { router } from 'expo-router';
import { userService } from './integrations/supabase/services';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    alignItems: 'center' as const,
    paddingVertical: 40,
  },
  logo: {
    fontSize: 32,
    fontWeight: '800' as const,
    color: colors.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginBottom: 32,
  },
  footer: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    paddingVertical: 20,
  },
  footerText: {
    fontSize: 16,
    color: colors.textLight,
  },
  loginLink: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '600' as const,
    marginLeft: 4,
  },
};

const SignupScreen: React.FC = () => {
  const { currentColors } = useTheme();
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    username: '',
    phone_number: '',
    password: '',
    confirm_password: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    let processedValue = value;
    
    // Special handling for phone number
    if (field === 'phone_number') {
      // Remove all non-digits
      processedValue = value.replace(/\D/g, '');
      // Limit to 10 digits
      if (processedValue.length > 10) {
        return; // Don't update if more than 10 digits
      }
    }
    
    setFormData(prev => ({ ...prev, [field]: processedValue }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    // Full name validation
    if (!formData.full_name.trim()) {
      newErrors.full_name = 'Full name is required';
    } else if (!/^[a-zA-Z\s]+$/.test(formData.full_name.trim())) {
      newErrors.full_name = 'Full name should only contain letters and spaces';
    }
    
    // Email validation
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    // Username validation
    if (!formData.username.trim()) {
      newErrors.username = 'Username is required';
    } else if (formData.username.length < 3) {
      newErrors.username = 'Username must be at least 3 characters long';
    }
    
    // Phone number validation
    if (!formData.phone_number.trim()) {
      newErrors.phone_number = 'Phone number is required';
    } else if (formData.phone_number.length !== 10) {
      newErrors.phone_number = 'Phone number must be exactly 10 digits';
    }
    
    // Password validation
    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters long';
    }
    
    // Confirm password validation
    if (!formData.confirm_password.trim()) {
      newErrors.confirm_password = 'Please confirm your password';
    } else if (formData.password !== formData.confirm_password) {
      newErrors.confirm_password = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      
      await userService.createUser({
        full_name: formData.full_name.trim(),
        email: formData.email.trim().toLowerCase(),
        username: formData.username.trim().toLowerCase(),
        phone_number: formData.phone_number,
        password: formData.password, // In production, this should be hashed
      });

      Alert.alert(
        'Account Created',
        'Welcome aboard! Your HOPEFUND account has been created. Let\'s get you started.',
        [
          {
            text: 'Continue to Login',
            onPress: () => router.replace('/login')
          }
        ]
      );
    } catch (error: any) {
      console.error('Signup error:', error);
      
      let errorMessage = 'Failed to create account. Please try again.';
      if (error.message?.includes('already exists')) {
        errorMessage = 'An account with this email or username already exists.';
      }
      
      Alert.alert('Signup Failed', errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getInputStyle = (fieldName: string) => [
    commonStyles.input,
    {
      backgroundColor: currentColors.backgroundAlt,
      borderColor: currentColors.border,
      color: currentColors.text,
    },
    errors[fieldName] && { borderColor: currentColors.error }
  ];

  const formatPhoneNumber = (value: string) => {
    if (value.length === 0) return '';
    if (value.length <= 3) return value;
    if (value.length <= 6) return `(${value.slice(0, 3)}) ${value.slice(3)}`;
    return `(${value.slice(0, 3)}) ${value.slice(3, 6)}-${value.slice(6, 10)}`;
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <KeyboardAwareScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.header}>
          <Text style={[styles.logo, { color: currentColors.primary }]}>HOPEFUND</Text>
          <Text style={[styles.subtitle, { color: currentColors.textLight }]}>
            Your Digital Wallet & Microbanking Platform
          </Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={[styles.title, { color: currentColors.text }]}>Create Account</Text>
          <Text style={[styles.description, { color: currentColors.textLight }]}>
            Join thousands of users managing their finances with HOPEFUND
          </Text>

          <TextInput
            style={getInputStyle('full_name')}
            placeholder="Full Name"
            placeholderTextColor={currentColors.textLight}
            value={formData.full_name}
            onChangeText={(value) => handleInputChange('full_name', value)}
            autoCapitalize="words"
          />
          {errors.full_name && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.full_name}
            </Text>
          )}

          <TextInput
            style={getInputStyle('email')}
            placeholder="Email Address"
            placeholderTextColor={currentColors.textLight}
            value={formData.email}
            onChangeText={(value) => handleInputChange('email', value)}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          {errors.email && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.email}
            </Text>
          )}

          <TextInput
            style={getInputStyle('username')}
            placeholder="Username"
            placeholderTextColor={currentColors.textLight}
            value={formData.username}
            onChangeText={(value) => handleInputChange('username', value)}
            autoCapitalize="none"
          />
          {errors.username && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.username}
            </Text>
          )}

          <TextInput
            style={getInputStyle('phone_number')}
            placeholder="Phone Number (10 digits)"
            placeholderTextColor={currentColors.textLight}
            value={formatPhoneNumber(formData.phone_number)}
            onChangeText={(value) => handleInputChange('phone_number', value.replace(/\D/g, ''))}
            keyboardType="phone-pad"
            maxLength={14} // Formatted length: (123) 456-7890
          />
          {errors.phone_number && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.phone_number}
            </Text>
          )}

          <TextInput
            style={getInputStyle('password')}
            placeholder="Password"
            placeholderTextColor={currentColors.textLight}
            value={formData.password}
            onChangeText={(value) => handleInputChange('password', value)}
            secureTextEntry
          />
          {errors.password && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.password}
            </Text>
          )}

          <TextInput
            style={getInputStyle('confirm_password')}
            placeholder="Confirm Password"
            placeholderTextColor={currentColors.textLight}
            value={formData.confirm_password}
            onChangeText={(value) => handleInputChange('confirm_password', value)}
            secureTextEntry
          />
          {errors.confirm_password && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.confirm_password}
            </Text>
          )}

          <Button
            text={loading ? "Creating Account..." : "Sign Up"}
            onPress={handleSignup}
            disabled={loading}
          />
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: currentColors.textLight }]}>
            Already have an account?
          </Text>
          <TouchableOpacity onPress={() => router.push('/login')}>
            <Text style={[styles.loginLink, { color: currentColors.primary }]}>
              Login
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default SignupScreen;