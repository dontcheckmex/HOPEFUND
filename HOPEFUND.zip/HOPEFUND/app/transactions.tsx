import React, { useState, useEffect, useCallback } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { View, Text, TouchableOpacity, ScrollView, RefreshControl } from 'react-native';
import { transactionService, Transaction } from './integrations/supabase/services';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import Icon from '../components/Icon';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  summaryCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    margin: 20,
  },
  summaryRow: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  summaryAmount: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  filterTabs: {
    flexDirection: 'row' as const,
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  filterTab: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center' as const,
    borderBottomWidth: 2,
  },
  filterTabText: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  transactionItem: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  transactionHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    marginBottom: 8,
  },
  transactionAmount: {
    fontSize: 18,
    fontWeight: '600' as const,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  transactionDate: {
    fontSize: 14,
    color: colors.textLight,
  },
  transactionStatus: {
    fontSize: 12,
    fontWeight: '600' as const,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    textAlign: 'center' as const,
  },
  emptyState: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginTop: 16,
  },
};

const TransactionsScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  const { currentColors } = useTheme();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [activeFilter, setActiveFilter] = useState<'all' | 'credit' | 'debit'>('all');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadTransactions = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const userTransactions = await transactionService.getUserTransactions(user.id);
      setTransactions(userTransactions);
      filterTransactions(userTransactions, activeFilter);
    } catch (error) {
      console.error('Error loading transactions:', error);
    } finally {
      setLoading(false);
    }
  }, [user, activeFilter]);

  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadTransactions();
    setRefreshing(false);
  };

  const filterTransactions = (allTransactions: Transaction[], filter: 'all' | 'credit' | 'debit') => {
    if (filter === 'all') {
      setFilteredTransactions(allTransactions);
    } else {
      setFilteredTransactions(allTransactions.filter(t => t.type === filter));
    }
  };

  const handleFilterChange = (filter: 'all' | 'credit' | 'debit') => {
    setActiveFilter(filter);
    filterTransactions(transactions, filter);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getTransactionColor = (type: string, status: string) => {
    if (status === 'failed') return currentColors.error;
    if (status === 'pending') return currentColors.warning;
    return type === 'credit' ? currentColors.success : currentColors.error;
  };

  const getTransactionIcon = (type: string, status: string) => {
    if (status === 'failed') return 'close-circle';
    if (status === 'pending') return 'time';
    return type === 'credit' ? 'arrow-down-circle' : 'arrow-up-circle';
  };

  const getTotalAmount = (type: 'credit' | 'debit') => {
    return transactions
      .filter(t => t.type === type && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Transactions</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Summary Card */}
        <View style={[styles.summaryCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: currentColors.text }]}>Total Credited</Text>
            <Text style={[styles.summaryAmount, { color: currentColors.success }]}>
              {formatCurrency(getTotalAmount('credit'))}
            </Text>
          </View>
          <View style={styles.summaryRow}>
            <Text style={[styles.summaryLabel, { color: currentColors.text }]}>Total Debited</Text>
            <Text style={[styles.summaryAmount, { color: currentColors.error }]}>
              {formatCurrency(getTotalAmount('debit'))}
            </Text>
          </View>
        </View>

        {/* Filter Tabs */}
        <View style={styles.filterTabs}>
          {(['all', 'credit', 'debit'] as const).map((filter) => (
            <TouchableOpacity
              key={filter}
              style={[
                styles.filterTab,
                {
                  borderBottomColor: activeFilter === filter ? currentColors.primary : currentColors.border,
                }
              ]}
              onPress={() => handleFilterChange(filter)}
            >
              <Text
                style={[
                  styles.filterTabText,
                  {
                    color: activeFilter === filter ? currentColors.primary : currentColors.textLight,
                  }
                ]}
              >
                {filter.charAt(0).toUpperCase() + filter.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Transactions List */}
        {loading ? (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>Loading transactions...</Text>
          </View>
        ) : filteredTransactions.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="receipt-outline" size={64} color={currentColors.textLight} />
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>
              {activeFilter === 'all' ? 'No transactions yet' : `No ${activeFilter} transactions`}
            </Text>
          </View>
        ) : (
          filteredTransactions.map((transaction) => (
            <View key={transaction.id} style={[styles.transactionItem, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
              <View style={styles.transactionHeader}>
                <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
                  <Icon
                    name={getTransactionIcon(transaction.type, transaction.status)}
                    size={24}
                    color={getTransactionColor(transaction.type, transaction.status)}
                    style={{ marginRight: 12 }}
                  />
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.transactionDescription, { color: currentColors.text }]}>
                      {transaction.description}
                    </Text>
                    <Text style={[styles.transactionDate, { color: currentColors.textLight }]}>
                      {formatDate(transaction.created_at)}
                    </Text>
                  </View>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text
                    style={[
                      styles.transactionAmount,
                      { color: getTransactionColor(transaction.type, transaction.status) }
                    ]}
                  >
                    {transaction.type === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                  </Text>
                  <Text
                    style={[
                      styles.transactionStatus,
                      {
                        backgroundColor: getTransactionColor(transaction.type, transaction.status) + '20',
                        color: getTransactionColor(transaction.type, transaction.status),
                      }
                    ]}
                  >
                    {transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
                  </Text>
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

export default TransactionsScreen;