import React, { useState, useEffect, useCallback } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { View, Text, TouchableOpacity, ScrollView, RefreshControl } from 'react-native';
import { transactionService, Transaction } from './integrations/supabase/services';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import Icon from '../components/Icon';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  logo: {
    fontSize: 24,
    fontWeight: '800' as const,
    color: colors.primary,
  },
  balanceCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 24,
    margin: 20,
    alignItems: 'center' as const,
  },
  balanceAmount: {
    fontSize: 36,
    fontWeight: '800' as const,
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 16,
    color: colors.textLight,
    marginBottom: 16,
  },
  pendingBalance: {
    fontSize: 14,
    color: colors.textLight,
  },
  quickActions: {
    flexDirection: 'row' as const,
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  quickAction: {
    flex: 1,
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginHorizontal: 8,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
  },
  quickActionText: {
    color: colors.backgroundAlt,
    fontSize: 16,
    fontWeight: '600' as const,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700' as const,
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  transactionItem: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginHorizontal: 20,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  transactionHeader: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
  },
  transactionInfo: {
    flex: 1,
    marginLeft: 12,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  transactionDate: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 2,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  viewAllButton: {
    alignItems: 'center' as const,
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  viewAllText: {
    fontSize: 16,
    fontWeight: '600' as const,
    color: colors.primary,
  },
  emptyState: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginTop: 16,
  },
};

const DashboardScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user, refreshUser } = useAuth();
  const { currentColors } = useTheme();
  const [recentTransactions, setRecentTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const loadRecentTransactions = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const transactions = await transactionService.getUserTransactions(user.id, 3);
      setRecentTransactions(transactions);
    } catch (error) {
      console.error('Error loading recent transactions:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadRecentTransactions();
  }, [loadRecentTransactions]);

  const onRefresh = async () => {
    setRefreshing(true);
    await Promise.all([refreshUser(), loadRecentTransactions()]);
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
    });
  };

  const getTransactionColor = (type: string, status: string) => {
    if (status === 'failed') return currentColors.error;
    if (status === 'pending') return currentColors.warning;
    return type === 'credit' ? currentColors.success : currentColors.error;
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <Text style={[styles.logo, { color: currentColors.primary }]}>HOPEFUND</Text>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Balance Card */}
        <View style={[styles.balanceCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
          <Text style={[styles.balanceLabel, { color: currentColors.textLight }]}>Available Balance</Text>
          <Text style={[styles.balanceAmount, { color: currentColors.secondary }]}>
            {formatCurrency(user?.available_balance || 0)}
          </Text>
          {user && user.pending_balance > 0 && (
            <Text style={[styles.pendingBalance, { color: currentColors.textLight }]}>
              Pending: {formatCurrency(user.pending_balance)}
            </Text>
          )}
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={[styles.quickAction, { backgroundColor: currentColors.primary }]}
            onPress={() => router.push('/linked-accounts')}
          >
            <Icon name="card-outline" size={24} color={currentColors.backgroundAlt} style={{ marginBottom: 8 }} />
            <Text style={[styles.quickActionText, { color: currentColors.backgroundAlt }]}>Link Account</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.quickAction, { backgroundColor: currentColors.primary }]}
            onPress={() => router.push('/withdraw')}
          >
            <Icon name="arrow-up-circle-outline" size={24} color={currentColors.backgroundAlt} style={{ marginBottom: 8 }} />
            <Text style={[styles.quickActionText, { color: currentColors.backgroundAlt }]}>Withdraw</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Transactions */}
        <Text style={[styles.sectionTitle, { color: currentColors.text }]}>Recent Transactions</Text>
        
        {loading ? (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>Loading transactions...</Text>
          </View>
        ) : recentTransactions.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="receipt-outline" size={48} color={currentColors.textLight} />
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>
              No transactions yet. Start by linking an account!
            </Text>
          </View>
        ) : (
          <>
            {recentTransactions.map((transaction) => (
              <View key={transaction.id} style={[styles.transactionItem, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
                <View style={styles.transactionHeader}>
                  <Icon
                    name={transaction.type === 'credit' ? 'arrow-down-circle' : 'arrow-up-circle'}
                    size={24}
                    color={getTransactionColor(transaction.type, transaction.status)}
                  />
                  <View style={styles.transactionInfo}>
                    <Text style={[styles.transactionDescription, { color: currentColors.text }]}>
                      {transaction.description}
                    </Text>
                    <Text style={[styles.transactionDate, { color: currentColors.textLight }]}>
                      {formatDate(transaction.created_at)}
                    </Text>
                  </View>
                  <Text
                    style={[
                      styles.transactionAmount,
                      { color: getTransactionColor(transaction.type, transaction.status) }
                    ]}
                  >
                    {transaction.type === 'credit' ? '+' : '-'}{formatCurrency(transaction.amount)}
                  </Text>
                </View>
              </View>
            ))}
            
            <TouchableOpacity
              style={styles.viewAllButton}
              onPress={() => router.push('/transactions')}
            >
              <Text style={[styles.viewAllText, { color: currentColors.primary }]}>View All Transactions</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

export default DashboardScreen;