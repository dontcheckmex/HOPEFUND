import { Text, View, Image, ScrollView, Dimensions } from 'react-native';
import { commonStyles, colors } from '../styles/commonStyles';
import { useState, useEffect } from 'react';
import Button from '../components/Button';
import { router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from '../components/Icon';

const { width } = Dimensions.get('window');

export default function MainScreen() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <SafeAreaView style={[commonStyles.container, commonStyles.centerContent]}>
        <View style={styles.logoContainer}>
          <Icon name="wallet-outline" size={80} color={colors.primary} />
          <Text style={styles.loadingLogo}>HOPEFUND</Text>
          <Text style={styles.loadingSubtitle}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={commonStyles.container}>
      <ScrollView 
        contentContainerStyle={commonStyles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.heroSection}>
          <View style={styles.logoContainer}>
            <Icon name="wallet-outline" size={100} color={colors.primary} />
            <Text style={styles.logo}>HOPEFUND</Text>
            <Text style={styles.tagline}>Modern Digital Wallet & Microbanking</Text>
          </View>

          <View style={styles.featuresContainer}>
            <Text style={styles.aboutTitle}>Secure Peer Finance</Text>
            <Text style={styles.aboutText}>
              Experience the future of digital banking with real-time balance tracking, 
              secure withdrawals, and seamless peer-to-peer transactions.
            </Text>

            <View style={styles.featuresList}>
              <View style={styles.featureItem}>
                <Icon name="shield-checkmark-outline" size={24} color={colors.primary} />
                <Text style={styles.featureText}>Bank-level Security</Text>
              </View>
              <View style={styles.featureItem}>
                <Icon name="flash-outline" size={24} color={colors.primary} />
                <Text style={styles.featureText}>Instant Transfers</Text>
              </View>
              <View style={styles.featureItem}>
                <Icon name="analytics-outline" size={24} color={colors.primary} />
                <Text style={styles.featureText}>Real-time Tracking</Text>
              </View>
              <View style={styles.featureItem}>
                <Icon name="people-outline" size={24} color={colors.primary} />
                <Text style={styles.featureText}>24/7 Support</Text>
              </View>
            </View>
          </View>

          <View style={styles.buttonContainer}>
            <Button
              text="Login"
              onPress={() => router.push('/login')}
              style={styles.primaryButton}
            />
            <Button
              text="Sign Up"
              onPress={() => router.push('/signup')}
              variant="secondary"
              style={styles.secondaryButton}
            />
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = {
  heroSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 40,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logo: {
    fontSize: 36,
    fontWeight: '800',
    color: colors.primary,
    marginTop: 16,
    fontFamily: 'Inter_800ExtraBold',
  },
  loadingLogo: {
    fontSize: 32,
    fontWeight: '800',
    color: colors.primary,
    marginTop: 16,
    fontFamily: 'Inter_800ExtraBold',
  },
  tagline: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center',
    marginTop: 8,
    fontFamily: 'Inter_400Regular',
  },
  loadingSubtitle: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center',
    marginTop: 8,
    fontFamily: 'Inter_400Regular',
  },
  featuresContainer: {
    width: '100%',
    marginBottom: 40,
  },
  aboutTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: colors.secondary,
    textAlign: 'center',
    marginBottom: 16,
    fontFamily: 'Inter_700Bold',
  },
  aboutText: {
    fontSize: 16,
    color: colors.text,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
    fontFamily: 'Inter_400Regular',
  },
  featuresList: {
    width: '100%',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  featureText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginLeft: 16,
    fontFamily: 'Inter_500Medium',
  },
  buttonContainer: {
    width: '100%',
    gap: 16,
  },
  primaryButton: {
    width: '100%',
  },
  secondaryButton: {
    width: '100%',
  },
};