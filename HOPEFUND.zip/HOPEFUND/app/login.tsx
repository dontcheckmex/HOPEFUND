import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from '../components/Icon';
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Alert } from 'react-native';
import { useAuth } from './context/AuthContext';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    alignItems: 'center' as const,
    paddingVertical: 40,
  },
  logo: {
    fontSize: 32,
    fontWeight: '800' as const,
    color: colors.primary,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
  },
  formContainer: {
    flex: 1,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginBottom: 32,
  },
  forgotPassword: {
    alignItems: 'center' as const,
    marginTop: 16,
    marginBottom: 32,
  },
  forgotPasswordText: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '500' as const,
  },
  footer: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    paddingVertical: 20,
  },
  footerText: {
    fontSize: 16,
    color: colors.textLight,
  },
  signupLink: {
    fontSize: 16,
    color: colors.primary,
    fontWeight: '600' as const,
    marginLeft: 4,
  },
};

const LoginScreen: React.FC = () => {
  const { login } = useAuth();
  const { currentColors } = useTheme();
  const [formData, setFormData] = useState({
    emailOrUsername: '',
    password: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleLogin = async () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.emailOrUsername.trim()) {
      newErrors.emailOrUsername = 'Email or username is required';
    }
    
    if (!formData.password.trim()) {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    
    if (Object.keys(newErrors).length > 0) {
      return;
    }

    try {
      setLoading(true);
      await login(formData.emailOrUsername, formData.password);
      router.replace('/dashboard');
    } catch (error) {
      console.error('Login error:', error);
      Alert.alert(
        'Login Failed',
        'Oops! That username or password didn\'t match our records. Need help? Reach out to our support team.',
        [
          { text: 'OK' },
          { 
            text: 'Contact Support', 
            onPress: () => router.push('/support')
          }
        ]
      );
    } finally {
      setLoading(false);
    }
  };

  const getInputStyle = (fieldName: string) => [
    commonStyles.input,
    {
      backgroundColor: currentColors.backgroundAlt,
      borderColor: currentColors.border,
      color: currentColors.text,
    },
    errors[fieldName] && { borderColor: currentColors.error }
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <KeyboardAwareScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }}>
        <View style={styles.header}>
          <Text style={[styles.logo, { color: currentColors.primary }]}>HOPEFUND</Text>
          <Text style={[styles.subtitle, { color: currentColors.textLight }]}>
            Your Digital Wallet & Microbanking Platform
          </Text>
        </View>

        <View style={styles.formContainer}>
          <Text style={[styles.title, { color: currentColors.text }]}>Welcome Back</Text>
          <Text style={[styles.description, { color: currentColors.textLight }]}>
            Sign in to access your account
          </Text>

          <TextInput
            style={getInputStyle('emailOrUsername')}
            placeholder="Email or Username"
            placeholderTextColor={currentColors.textLight}
            value={formData.emailOrUsername}
            onChangeText={(value) => handleInputChange('emailOrUsername', value)}
            autoCapitalize="none"
            keyboardType="email-address"
          />
          {errors.emailOrUsername && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.emailOrUsername}
            </Text>
          )}

          <TextInput
            style={getInputStyle('password')}
            placeholder="Password"
            placeholderTextColor={currentColors.textLight}
            value={formData.password}
            onChangeText={(value) => handleInputChange('password', value)}
            secureTextEntry
          />
          {errors.password && (
            <Text style={[commonStyles.errorText, { color: currentColors.error }]}>
              {errors.password}
            </Text>
          )}

          <Button
            text={loading ? "Signing In..." : "Login"}
            onPress={handleLogin}
            disabled={loading}
          />

          <TouchableOpacity style={styles.forgotPassword}>
            <Text style={[styles.forgotPasswordText, { color: currentColors.primary }]}>
              Forgot Password?
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: currentColors.textLight }]}>
            Don't have an account?
          </Text>
          <TouchableOpacity onPress={() => router.push('/signup')}>
            <Text style={[styles.signupLink, { color: currentColors.primary }]}>
              Sign Up
            </Text>
          </TouchableOpacity>
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default LoginScreen;