import React, { useState, useEffect, useCallback } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { View, Text, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from '../components/Icon';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { router } from 'expo-router';
import { linkedAccountService, transactionService, userService, LinkedAccount } from './integrations/supabase/services';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  balanceCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    margin: 20,
    alignItems: 'center' as const,
  },
  balanceAmount: {
    fontSize: 32,
    fontWeight: '800' as const,
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 16,
    color: colors.textLight,
  },
  formContainer: {
    padding: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600' as const,
    marginBottom: 16,
  },
  accountSelector: {
    borderRadius: 12,
    borderWidth: 2,
    marginBottom: 16,
    overflow: 'hidden' as const,
  },
  accountOption: {
    padding: 16,
    borderBottomWidth: 1,
  },
  accountInfo: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
  },
  accountName: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  accountDetails: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  amountInput: {
    fontSize: 24,
    fontWeight: '600' as const,
    textAlign: 'center' as const,
    paddingVertical: 20,
    borderRadius: 12,
    borderWidth: 2,
    marginBottom: 16,
  },
  limitText: {
    fontSize: 14,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginBottom: 24,
  },
  disabledContainer: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 60,
  },
  disabledText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginTop: 16,
  },
  processingOverlay: {
    position: 'absolute' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center' as const,
    alignItems: 'center' as const,
    zIndex: 1000,
  },
  processingText: {
    color: colors.backgroundAlt,
    fontSize: 18,
    fontWeight: '600' as const,
    marginTop: 16,
  },
};

const WithdrawScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user, updateUser } = useAuth();
  const { currentColors } = useTheme();
  const [linkedAccounts, setLinkedAccounts] = useState<LinkedAccount[]>([]);
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [amount, setAmount] = useState('');
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  const loadLinkedAccounts = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const accounts = await linkedAccountService.getUserLinkedAccounts(user.id);
      const verifiedAccounts = accounts.filter(account => account.status === 'verified');
      setLinkedAccounts(verifiedAccounts);
      
      if (verifiedAccounts.length > 0 && !selectedAccountId) {
        setSelectedAccountId(verifiedAccounts[0].id);
      }
    } catch (error) {
      console.error('Error loading linked accounts:', error);
      Alert.alert('Error', 'Failed to load linked accounts');
    } finally {
      setLoading(false);
    }
  }, [user, selectedAccountId]);

  useEffect(() => {
    loadLinkedAccounts();
  }, [loadLinkedAccounts]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };

  const handleAmountChange = (value: string) => {
    // Remove non-numeric characters except decimal point
    const numericValue = value.replace(/[^0-9.]/g, '');
    
    // Ensure only one decimal point
    const parts = numericValue.split('.');
    if (parts.length > 2) {
      return;
    }
    
    // Limit to 2 decimal places
    if (parts[1] && parts[1].length > 2) {
      return;
    }
    
    setAmount(numericValue);
  };

  const validateWithdrawal = () => {
    const withdrawAmount = parseFloat(amount);
    
    if (!amount || isNaN(withdrawAmount)) {
      Alert.alert('Invalid Amount', 'Please enter a valid amount');
      return false;
    }
    
    if (withdrawAmount < 10) {
      Alert.alert('Minimum Withdrawal', 'Minimum withdrawal is $10. Please try again.');
      return false;
    }
    
    if (withdrawAmount > 100000) {
      Alert.alert('Maximum Withdrawal', 'The maximum withdrawal amount is $100,000.');
      return false;
    }
    
    if (!user || withdrawAmount > user.available_balance) {
      Alert.alert('Insufficient Funds', 'Insufficient funds. Please check your balance and try again.');
      return false;
    }
    
    if (!selectedAccountId) {
      Alert.alert('No Account Selected', 'Please select a linked account');
      return false;
    }
    
    return true;
  };

  const handleWithdraw = async () => {
    if (!validateWithdrawal() || !user) return;
    
    const withdrawAmount = parseFloat(amount);
    
    try {
      setProcessing(true);
      
      // Optimistic UI update - subtract from available balance immediately
      const newAvailableBalance = user.available_balance - withdrawAmount;
      const newPendingBalance = user.pending_balance + withdrawAmount;
      
      // Update user balance in UI
      await updateUser({
        available_balance: newAvailableBalance,
        pending_balance: newPendingBalance,
      });
      
      // Create pending transaction
      await transactionService.createTransaction(user.id, {
        amount: withdrawAmount,
        type: 'debit',
        description: `Withdrawal to ${getSelectedAccountInfo()?.bank_name}`,
        status: 'pending',
        linked_account_id: selectedAccountId,
      });
      
      // Update balance in database
      await userService.updateBalance(user.id, newAvailableBalance, newPendingBalance);
      
      Alert.alert(
        'Withdrawal Submitted',
        'Withdrawal submitted! Funds are being processed and will appear shortly.',
        [
          {
            text: 'OK',
            onPress: () => {
              setAmount('');
              router.back();
            }
          }
        ]
      );
      
    } catch (error) {
      console.error('Error processing withdrawal:', error);
      
      // Revert optimistic update on error
      await updateUser({
        available_balance: user.available_balance,
        pending_balance: user.pending_balance,
      });
      
      Alert.alert('Error', 'Failed to process withdrawal. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const getSelectedAccountInfo = () => {
    return linkedAccounts.find(account => account.id === selectedAccountId);
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
        <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
          <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
            <Icon name="menu" size={24} color={currentColors.primary} />
          </TouchableOpacity>
          <Text style={[styles.title, { color: currentColors.text }]}>Withdraw</Text>
          <View style={{ width: 24 }} />
        </View>
        <View style={[commonStyles.centerContent]}>
          <Text style={[commonStyles.text, { color: currentColors.textLight }]}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (linkedAccounts.length === 0) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
        <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
          <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
            <Icon name="menu" size={24} color={currentColors.primary} />
          </TouchableOpacity>
          <Text style={[styles.title, { color: currentColors.text }]}>Withdraw</Text>
          <View style={{ width: 24 }} />
        </View>
        
        <View style={styles.disabledContainer}>
          <Icon name="card-outline" size={64} color={currentColors.textLight} />
          <Text style={[styles.disabledText, { color: currentColors.textLight }]}>
            Link an account to enable withdrawal
          </Text>
          <Button
            text="Link Account"
            onPress={() => router.push('/linked-accounts')}
            style={{ marginTop: 24 }}
          />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      {processing && (
        <View style={styles.processingOverlay}>
          <Icon name="hourglass" size={48} color={currentColors.backgroundAlt} />
          <Text style={[styles.processingText, { color: currentColors.backgroundAlt }]}>Processing...</Text>
        </View>
      )}
      
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Withdraw</Text>
        <View style={{ width: 24 }} />
      </View>

      <KeyboardAwareScrollView style={{ flex: 1 }}>
        {/* Available Balance */}
        <View style={[styles.balanceCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
          <Text style={[styles.balanceLabel, { color: currentColors.textLight }]}>Available Balance</Text>
          <Text style={[styles.balanceAmount, { color: currentColors.secondary }]}>
            {formatCurrency(user?.available_balance || 0)}
          </Text>
        </View>

        <View style={styles.formContainer}>
          {/* Account Selection */}
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>Select Account</Text>
          <View style={[styles.accountSelector, { borderColor: currentColors.border }]}>
            {linkedAccounts.map((account, index) => (
              <TouchableOpacity
                key={account.id}
                style={[
                  styles.accountOption,
                  {
                    backgroundColor: selectedAccountId === account.id ? currentColors.primary + '10' : currentColors.backgroundAlt,
                    borderBottomColor: currentColors.border,
                    borderBottomWidth: index < linkedAccounts.length - 1 ? 1 : 0,
                  }
                ]}
                onPress={() => setSelectedAccountId(account.id)}
              >
                <View style={styles.accountInfo}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.accountName, { color: currentColors.text }]}>{account.bank_name}</Text>
                    <Text style={[styles.accountDetails, { color: currentColors.textLight }]}>
                      {account.account_type.charAt(0).toUpperCase() + account.account_type.slice(1)} •••• {account.last_four_digits}
                    </Text>
                  </View>
                  {selectedAccountId === account.id && (
                    <Icon name="checkmark-circle" size={24} color={currentColors.primary} />
                  )}
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Amount Input */}
          <Text style={[styles.sectionTitle, { color: currentColors.text }]}>Amount</Text>
          <TextInput
            style={[
              styles.amountInput,
              {
                backgroundColor: currentColors.backgroundAlt,
                borderColor: currentColors.border,
                color: currentColors.text,
              }
            ]}
            placeholder="$0.00"
            placeholderTextColor={currentColors.textLight}
            value={amount ? `$${amount}` : ''}
            onChangeText={(value) => handleAmountChange(value.replace('$', ''))}
            keyboardType="numeric"
          />
          
          <Text style={[styles.limitText, { color: currentColors.textLight }]}>
            Minimum: $10 • Maximum: $100,000
          </Text>

          <Button
            text="Withdraw"
            onPress={handleWithdraw}
            disabled={!amount || processing}
          />
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default WithdrawScreen;