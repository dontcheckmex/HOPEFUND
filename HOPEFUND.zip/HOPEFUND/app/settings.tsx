import React, { useState, useEffect, useCallback } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { deviceService, UserDevice } from './integrations/supabase/services';
import { View, Text, TouchableOpacity, ScrollView, Switch, Alert } from 'react-native';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import Icon from '../components/Icon';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  section: {
    backgroundColor: colors.card,
    marginVertical: 8,
    marginHorizontal: 20,
    borderRadius: 12,
    overflow: 'hidden' as const,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600' as const,
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  settingItem: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  settingIcon: {
    marginRight: 16,
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  settingSubtitle: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 2,
  },
  deviceItem: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  deviceInfo: {
    flex: 1,
    marginLeft: 12,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: '500' as const,
  },
  deviceDetails: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 2,
  },
  currentDeviceBadge: {
    backgroundColor: colors.success,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  currentDeviceText: {
    color: colors.backgroundAlt,
    fontSize: 12,
    fontWeight: '600' as const,
  },
  logoutButton: {
    backgroundColor: colors.error,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
  },
  logoutButtonText: {
    color: colors.backgroundAlt,
    fontSize: 14,
    fontWeight: '600' as const,
  },
  emptyState: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 40,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginTop: 16,
  },
};

const SettingsScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user, logout } = useAuth();
  const { isDarkMode, toggleDarkMode, currentColors } = useTheme();
  const [loggedDevices, setLoggedDevices] = useState<UserDevice[]>([]);
  const [loading, setLoading] = useState(true);

  const loadLoggedDevices = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const devices = await deviceService.getUserDevices(user.id);
      setLoggedDevices(devices);
    } catch (error) {
      console.error('Error loading logged devices:', error);
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadLoggedDevices();
  }, [loadLoggedDevices]);

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleChangePassword = () => {
    Alert.alert(
      'Change Password',
      'This feature will be available in a future update.',
      [{ text: 'OK' }]
    );
  };

  const handleLogoutOtherDevices = () => {
    Alert.alert(
      'Logout Other Devices',
      'Are you sure you want to logout all other devices? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout All',
          style: 'destructive',
          onPress: async () => {
            try {
              const currentDevice = loggedDevices.find(device => device.is_current);
              if (currentDevice && user) {
                await deviceService.logoutOtherDevices(user.id, currentDevice.session_id || '');
                await loadLoggedDevices();
                Alert.alert('Success', 'All other devices have been logged out.');
              }
            } catch (error) {
              console.error('Error logging out other devices:', error);
              Alert.alert('Error', 'Failed to logout other devices. Please try again.');
            }
          }
        }
      ]
    );
  };

  const SettingItem = ({
    icon,
    title,
    subtitle,
    onPress,
    rightComponent,
  }: {
    icon: string;
    title: string;
    subtitle?: string;
    onPress?: () => void;
    rightComponent?: React.ReactNode;
  }) => (
    <TouchableOpacity
      style={[styles.settingItem, { borderBottomColor: currentColors.border }]}
      onPress={onPress}
      disabled={!onPress}
    >
      <Icon name={icon as any} size={24} color={currentColors.primary} style={styles.settingIcon} />
      <View style={styles.settingContent}>
        <Text style={[styles.settingTitle, { color: currentColors.text }]}>{title}</Text>
        {subtitle && (
          <Text style={[styles.settingSubtitle, { color: currentColors.textLight }]}>{subtitle}</Text>
        )}
      </View>
      {rightComponent || (onPress && <Icon name="chevron-forward" size={20} color={currentColors.textLight} />)}
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Settings</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={{ flex: 1 }}>
        {/* Account Settings */}
        <View style={[styles.section, { backgroundColor: currentColors.card }]}>
          <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border }]}>
            Account
          </Text>
          <SettingItem
            icon="person-outline"
            title="Profile"
            subtitle="Update your personal information"
            onPress={() => router.push('/profile')}
          />
          <SettingItem
            icon="lock-closed-outline"
            title="Change Password"
            subtitle="Update your account password"
            onPress={handleChangePassword}
          />
        </View>

        {/* Preferences */}
        <View style={[styles.section, { backgroundColor: currentColors.card }]}>
          <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border }]}>
            Preferences
          </Text>
          <SettingItem
            icon="moon-outline"
            title="Dark Mode"
            subtitle="Toggle dark theme"
            rightComponent={
              <Switch
                value={isDarkMode}
                onValueChange={toggleDarkMode}
                trackColor={{ false: currentColors.border, true: currentColors.primary }}
                thumbColor={currentColors.backgroundAlt}
              />
            }
          />
          <SettingItem
            icon="notifications-outline"
            title="Email Preferences"
            subtitle="Manage email notifications"
            onPress={() => Alert.alert('Coming Soon', 'This feature will be available in a future update.')}
          />
          <SettingItem
            icon="phone-portrait-outline"
            title="Notification Preferences"
            subtitle="Manage push notifications"
            onPress={() => Alert.alert('Coming Soon', 'This feature will be available in a future update.')}
          />
        </View>

        {/* Logged Devices */}
        <View style={[styles.section, { backgroundColor: currentColors.card }]}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
            <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border, flex: 1 }]}>
              Logged Devices
            </Text>
            {loggedDevices.filter(device => !device.is_current).length > 0 && (
              <TouchableOpacity
                style={[styles.logoutButton, { backgroundColor: currentColors.error, marginRight: 20 }]}
                onPress={handleLogoutOtherDevices}
              >
                <Text style={[styles.logoutButtonText, { color: currentColors.backgroundAlt }]}>
                  Logout All
                </Text>
              </TouchableOpacity>
            )}
          </View>
          
          {loading ? (
            <View style={styles.emptyState}>
              <Text style={[styles.emptyText, { color: currentColors.textLight }]}>Loading devices...</Text>
            </View>
          ) : loggedDevices.length === 0 ? (
            <View style={styles.emptyState}>
              <Icon name="phone-portrait-outline" size={48} color={currentColors.textLight} />
              <Text style={[styles.emptyText, { color: currentColors.textLight }]}>No devices found</Text>
            </View>
          ) : (
            loggedDevices.map((device) => (
              <View key={device.id} style={[styles.deviceItem, { borderBottomColor: currentColors.border }]}>
                <Icon
                  name={device.device_model?.toLowerCase().includes('iphone') || device.device_model?.toLowerCase().includes('ios') ? 'phone-portrait' : 'phone-portrait-outline'}
                  size={24}
                  color={device.is_current ? currentColors.primary : currentColors.textLight}
                />
                <View style={styles.deviceInfo}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Text style={[styles.deviceName, { color: currentColors.text }]}>
                      {device.device_model || 'Unknown Device'}
                    </Text>
                    {device.is_current && (
                      <View style={[styles.currentDeviceBadge, { backgroundColor: currentColors.success }]}>
                        <Text style={[styles.currentDeviceText, { color: currentColors.backgroundAlt }]}>
                          Current
                        </Text>
                      </View>
                    )}
                  </View>
                  <Text style={[styles.deviceDetails, { color: currentColors.textLight }]}>
                    Last login: {formatDate(device.last_login_at)}
                    {device.location && ` • ${device.location}`}
                  </Text>
                </View>
              </View>
            ))
          )}
        </View>

        {/* Support */}
        <View style={[styles.section, { backgroundColor: currentColors.card }]}>
          <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border }]}>
            Support
          </Text>
          <SettingItem
            icon="help-circle-outline"
            title="Help & Support"
            subtitle="Get help or contact support"
            onPress={() => router.push('/support')}
          />
          <SettingItem
            icon="log-out-outline"
            title="Logout"
            subtitle="Sign out of your account"
            onPress={() => {
              Alert.alert(
                'Logout',
                'Are you sure you want to logout?',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Logout', style: 'destructive', onPress: logout }
                ]
              );
            }}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SettingsScreen;