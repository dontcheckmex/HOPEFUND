import React, { useState, useEffect } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { View, Text, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from '../components/Icon';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  profileCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    margin: 20,
    alignItems: 'center' as const,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: colors.primary,
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    marginBottom: 16,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '700' as const,
    color: colors.backgroundAlt,
  },
  userName: {
    fontSize: 24,
    fontWeight: '700' as const,
    marginBottom: 8,
  },
  userEmail: {
    fontSize: 16,
    color: colors.textLight,
    marginBottom: 16,
  },
  completionBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: colors.warning,
  },
  completionText: {
    fontSize: 12,
    fontWeight: '600' as const,
    color: colors.backgroundAlt,
  },
  formContainer: {
    padding: 20,
  },
  fieldLabel: {
    fontSize: 16,
    fontWeight: '500' as const,
    marginBottom: 8,
  },
  readOnlyField: {
    backgroundColor: colors.border,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 16,
    fontSize: 16,
    marginBottom: 16,
    opacity: 0.7,
  },
  buttonRow: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    marginTop: 24,
  },
  halfButton: {
    flex: 0.48,
  },
};

const ProfileScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user, updateUser } = useAuth();
  const { currentColors } = useTheme();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    username: '',
    phone_number: '',
    address: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (user) {
      setFormData({
        full_name: user.full_name || '',
        email: user.email || '',
        username: user.username || '',
        phone_number: user.phone_number || '',
        address: user.address || '',
      });
    }
  }, [user]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleSave = async () => {
    if (!user) return;

    try {
      await updateUser({
        address: formData.address,
        profile_completed: formData.address.trim() !== '',
      });
      
      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', 'Failed to update profile. Please try again.');
    }
  };

  const handleCancel = () => {
    if (user) {
      setFormData({
        full_name: user.full_name || '',
        email: user.email || '',
        username: user.username || '',
        phone_number: user.phone_number || '',
        address: user.address || '',
      });
    }
    setIsEditing(false);
    setErrors({});
  };

  const getInputStyle = (fieldName: string) => [
    commonStyles.input,
    {
      backgroundColor: currentColors.backgroundAlt,
      borderColor: currentColors.border,
      color: currentColors.text,
    },
    errors[fieldName] && { borderColor: currentColors.error }
  ];

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  if (!user) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
        <View style={[commonStyles.centerContent]}>
          <Text style={[commonStyles.text, { color: currentColors.textLight }]}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Profile</Text>
        <TouchableOpacity onPress={() => setIsEditing(!isEditing)}>
          <Icon name={isEditing ? "close" : "create-outline"} size={24} color={currentColors.primary} />
        </TouchableOpacity>
      </View>

      <KeyboardAwareScrollView style={{ flex: 1 }}>
        {/* Profile Card */}
        <View style={[styles.profileCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
          <View style={[styles.avatar, { backgroundColor: currentColors.primary }]}>
            <Text style={[styles.avatarText, { color: currentColors.backgroundAlt }]}>
              {getInitials(user.full_name)}
            </Text>
          </View>
          <Text style={[styles.userName, { color: currentColors.text }]}>{user.full_name}</Text>
          <Text style={[styles.userEmail, { color: currentColors.textLight }]}>{user.email}</Text>
          
          <View style={[
            styles.completionBadge,
            { backgroundColor: user.profile_completed ? currentColors.success : currentColors.warning }
          ]}>
            <Text style={[styles.completionText, { color: currentColors.backgroundAlt }]}>
              {user.profile_completed ? 'Profile Complete' : 'Profile Incomplete'}
            </Text>
          </View>
        </View>

        {/* Profile Form */}
        <View style={styles.formContainer}>
          <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Full Name</Text>
          <Text style={[styles.readOnlyField, { backgroundColor: currentColors.border, color: currentColors.textLight }]}>
            {formData.full_name}
          </Text>

          <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Email</Text>
          <Text style={[styles.readOnlyField, { backgroundColor: currentColors.border, color: currentColors.textLight }]}>
            {formData.email}
          </Text>

          <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Username</Text>
          <Text style={[styles.readOnlyField, { backgroundColor: currentColors.border, color: currentColors.textLight }]}>
            {formData.username}
          </Text>

          <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Phone Number</Text>
          <Text style={[styles.readOnlyField, { backgroundColor: currentColors.border, color: currentColors.textLight }]}>
            {formData.phone_number}
          </Text>

          <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Address</Text>
          <TextInput
            style={getInputStyle('address')}
            placeholder="Enter your address"
            placeholderTextColor={currentColors.textLight}
            value={formData.address}
            onChangeText={(value) => handleInputChange('address', value)}
            editable={isEditing}
            multiline
            numberOfLines={3}
          />
          {errors.address && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.address}</Text>}

          {isEditing && (
            <View style={styles.buttonRow}>
              <Button
                text="Cancel"
                onPress={handleCancel}
                variant="outline"
                style={styles.halfButton}
              />
              <Button
                text="Save"
                onPress={handleSave}
                style={styles.halfButton}
              />
            </View>
          )}
        </View>
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default ProfileScreen;