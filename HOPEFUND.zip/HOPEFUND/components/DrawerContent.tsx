import Icon from './Icon';
import { colors, commonStyles } from '../styles/commonStyles';
import React from 'react';
import { DrawerContentScrollView, DrawerContentComponentProps } from '@react-navigation/drawer';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, Alert } from 'react-native';
import { useAuth } from '../app/context/AuthContext';
import { router } from 'expo-router';
import { useTheme } from '../app/context/ThemeContext';

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    padding: 20,
    borderBottomWidth: 1,
    alignItems: 'center',
  },
  logo: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.primary,
    marginBottom: 8,
  },
  userInfo: {
    alignItems: 'center',
  },
  userName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: colors.textLight,
  },
  menuSection: {
    flex: 1,
    paddingTop: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
  },
  menuItemActive: {
    backgroundColor: colors.primary + '10',
    borderRightWidth: 4,
    borderRightColor: colors.primary,
  },
  menuItemIcon: {
    marginRight: 16,
    width: 24,
    alignItems: 'center',
  },
  menuItemText: {
    fontSize: 16,
    fontWeight: '500',
    flex: 1,
  },
  footer: {
    padding: 20,
    borderTopWidth: 1,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '500',
    marginLeft: 16,
    color: colors.error,
  },
});

const DrawerContent: React.FC<DrawerContentComponentProps> = (props) => {
  const { user, logout } = useAuth();
  const { currentColors } = useTheme();

  const menuItems = [
    { name: 'Dashboard', icon: 'home-outline', route: '/dashboard' },
    { name: 'Profile', icon: 'person-outline', route: '/profile' },
    { name: 'Linked Accounts', icon: 'card-outline', route: '/linked-accounts' },
    { name: 'Withdraw', icon: 'arrow-up-circle-outline', route: '/withdraw' },
    { name: 'Transactions', icon: 'receipt-outline', route: '/transactions' },
    { name: 'Settings', icon: 'settings-outline', route: '/settings' },
    { name: 'Support', icon: 'help-circle-outline', route: '/support' },
  ];

  const handleNavigation = (route: string) => {
    props.navigation.closeDrawer();
    router.push(route);
  };

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: () => {
            props.navigation.closeDrawer();
            logout();
          }
        }
      ]
    );
  };

  const getCurrentRoute = () => {
    return props.state.routes[props.state.index]?.name || '';
  };

  return (
    <View style={[styles.container, { backgroundColor: currentColors.background }]}>
      {/* Header */}
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <Text style={[styles.logo, { color: currentColors.primary }]}>HOPEFUND</Text>
        {user && (
          <View style={styles.userInfo}>
            <Text style={[styles.userName, { color: currentColors.text }]}>{user.full_name}</Text>
            <Text style={[styles.userEmail, { color: currentColors.textLight }]}>{user.email}</Text>
          </View>
        )}
      </View>

      {/* Menu Items */}
      <ScrollView style={styles.menuSection}>
        {menuItems.map((item) => {
          const isActive = getCurrentRoute() === item.route.replace('/', '');
          return (
            <TouchableOpacity
              key={item.name}
              style={[
                styles.menuItem,
                { borderBottomColor: currentColors.border },
                isActive && [styles.menuItemActive, { 
                  backgroundColor: currentColors.primary + '10',
                  borderRightColor: currentColors.primary 
                }]
              ]}
              onPress={() => handleNavigation(item.route)}
            >
              <View style={styles.menuItemIcon}>
                <Icon
                  name={item.icon as any}
                  size={24}
                  color={isActive ? currentColors.primary : currentColors.text}
                />
              </View>
              <Text
                style={[
                  styles.menuItemText,
                  {
                    color: isActive ? currentColors.primary : currentColors.text,
                    fontWeight: isActive ? '600' : '500'
                  }
                ]}
              >
                {item.name}
              </Text>
              {isActive && (
                <Icon name="chevron-forward" size={20} color={currentColors.primary} />
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Footer */}
      <View style={[styles.footer, { borderTopColor: currentColors.border }]}>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Icon name="log-out-outline" size={24} color={currentColors.error} />
          <Text style={[styles.logoutText, { color: currentColors.error }]}>Logout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default DrawerContent;