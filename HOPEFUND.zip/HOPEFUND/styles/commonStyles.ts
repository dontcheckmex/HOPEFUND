import { StyleSheet, ViewStyle, TextStyle } from 'react-native';

export const colors = {
  primary: '#FF6A00',      // Orange primary
  secondary: '#2D2D7F',    // Deep Indigo
  accent: '#F8C471',       // Soft Gold
  background: '#F5F6F8',   // Cool Gray background
  backgroundAlt: '#FFFFFF', // White
  text: '#2D2D7F',         // Deep Indigo text
  textLight: '#666666',    // Light gray text
  success: '#4CAF50',      // Success green
  warning: '#FF9800',      // Warning orange
  error: '#F44336',        // Error red
  border: '#E0E0E0',       // Light border
  card: '#FFFFFF',         // White card background
  shadow: 'rgba(0, 0, 0, 0.1)',
  // Dark mode colors
  darkBackground: '#1A1A1A',
  darkCard: '#2D2D2D',
  darkText: '#FFFFFF',
  darkTextLight: '#CCCCCC',
  darkBorder: '#404040',
};

export const buttonStyles = StyleSheet.create({
  primary: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0px 4px 12px rgba(255, 106, 0, 0.3)',
    elevation: 6,
  },
  secondary: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
    boxShadow: '0px 2px 8px rgba(0, 0, 0, 0.1)',
    elevation: 3,
  },
  outline: {
    backgroundColor: 'transparent',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: colors.primary,
  },
});

export const commonStyles = StyleSheet.create({
  wrapper: {
    backgroundColor: colors.background,
    width: '100%',
    height: '100%',
  },
  container: {
    flex: 1,
    backgroundColor: colors.background,
    width: '100%',
    height: '100%',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    maxWidth: 800,
    width: '100%',
    paddingHorizontal: 20,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    textAlign: 'center',
    color: colors.secondary,
    marginBottom: 8,
    fontFamily: 'Inter_800ExtraBold',
  },
  subtitle: {
    fontSize: 18,
    fontWeight: '600',
    textAlign: 'center',
    color: colors.text,
    marginBottom: 24,
    fontFamily: 'Inter_600SemiBold',
  },
  text: {
    fontSize: 16,
    fontWeight: '400',
    color: colors.text,
    marginBottom: 8,
    lineHeight: 24,
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
  },
  textLight: {
    fontSize: 14,
    fontWeight: '400',
    color: colors.textLight,
    marginBottom: 8,
    lineHeight: 20,
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
  },
  section: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 24,
  },
  card: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    marginVertical: 8,
    width: '100%',
    boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.08)',
    elevation: 4,
    borderWidth: 1,
    borderColor: colors.border,
  },
  input: {
    backgroundColor: colors.backgroundAlt,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 16,
    fontSize: 16,
    color: colors.text,
    borderWidth: 2,
    borderColor: colors.border,
    marginBottom: 16,
    fontFamily: 'Inter_400Regular',
  },
  inputFocused: {
    borderColor: colors.primary,
    boxShadow: '0px 0px 0px 3px rgba(255, 106, 0, 0.1)',
  },
  inputError: {
    borderColor: colors.error,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.backgroundAlt,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  logo: {
    fontSize: 24,
    fontWeight: '800',
    color: colors.primary,
    fontFamily: 'Inter_800ExtraBold',
  },
  balance: {
    fontSize: 32,
    fontWeight: '800',
    color: colors.secondary,
    textAlign: 'center',
    marginBottom: 8,
    fontFamily: 'Inter_800ExtraBold',
  },
  balanceLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.textLight,
    textAlign: 'center',
    marginBottom: 4,
    fontFamily: 'Inter_500Medium',
  },
  quickAction: {
    backgroundColor: colors.primary,
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
    boxShadow: '0px 2px 8px rgba(255, 106, 0, 0.3)',
    elevation: 4,
  },
  quickActionText: {
    color: colors.backgroundAlt,
    fontSize: 14,
    fontWeight: '600',
    fontFamily: 'Inter_600SemiBold',
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: '600',
    fontFamily: 'Inter_600SemiBold',
  },
  transactionDescription: {
    fontSize: 14,
    color: colors.textLight,
    fontFamily: 'Inter_400Regular',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  menuItemText: {
    fontSize: 16,
    fontWeight: '500',
    color: colors.text,
    marginLeft: 16,
    fontFamily: 'Inter_500Medium',
  },
  errorText: {
    color: colors.error,
    fontSize: 14,
    marginBottom: 8,
    fontFamily: 'Inter_400Regular',
  },
  successText: {
    color: colors.success,
    fontSize: 14,
    marginBottom: 8,
    fontFamily: 'Inter_400Regular',
  },
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  spaceBetween: {
    justifyContent: 'space-between',
  },
  mt16: {
    marginTop: 16,
  },
  mt24: {
    marginTop: 24,
  },
  mb16: {
    marginBottom: 16,
  },
  mb24: {
    marginBottom: 24,
  },
});