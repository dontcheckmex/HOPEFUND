import React, { useState, useEffect, useCallback } from 'react';
import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import { View, Text, TouchableOpacity, ScrollView, Alert, TextInput } from 'react-native';
import Icon from '../components/Icon';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import { linkedAccountService, LinkedAccount } from './integrations/supabase/services';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  accountCard: {
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 16,
    marginVertical: 8,
    marginHorizontal: 20,
    borderWidth: 1,
    borderColor: colors.border,
  },
  accountInfo: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
  },
  bankName: {
    fontSize: 16,
    fontWeight: '600' as const,
  },
  accountDetails: {
    fontSize: 14,
    color: colors.textLight,
    marginTop: 4,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    alignItems: 'center' as const,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600' as const,
  },
  addButton: {
    margin: 20,
  },
  formContainer: {
    padding: 20,
  },
  stepIndicator: {
    flexDirection: 'row' as const,
    justifyContent: 'center' as const,
    marginBottom: 24,
  },
  stepDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginHorizontal: 4,
  },
  stepActive: {
    backgroundColor: colors.primary,
  },
  stepInactive: {
    backgroundColor: colors.border,
  },
  stepTitle: {
    fontSize: 20,
    fontWeight: '600' as const,
    textAlign: 'center' as const,
    marginBottom: 24,
  },
  buttonRow: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    marginTop: 24,
  },
  halfButton: {
    flex: 0.48,
  },
  emptyState: {
    alignItems: 'center' as const,
    justifyContent: 'center' as const,
    paddingVertical: 60,
  },
  emptyText: {
    fontSize: 16,
    color: colors.textLight,
    textAlign: 'center' as const,
    marginTop: 16,
  },
};

const LinkedAccountsScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  const { currentColors } = useTheme();
  const [linkedAccounts, setLinkedAccounts] = useState<LinkedAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    bank_name: '',
    account_type: 'checking' as 'checking' | 'savings',
    account_username: '',
    account_password: '',
    card_number: '',
    expiry_date: '',
    cvv: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const loadLinkedAccounts = useCallback(async () => {
    if (!user) return;
    
    try {
      setLoading(true);
      const accounts = await linkedAccountService.getUserLinkedAccounts(user.id);
      setLinkedAccounts(accounts);
    } catch (error) {
      console.error('Error loading linked accounts:', error);
      Alert.alert('Error', 'Failed to load linked accounts');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    loadLinkedAccounts();
  }, [loadLinkedAccounts]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.bank_name.trim()) {
      newErrors.bank_name = 'Bank name is required';
    }
    if (!formData.account_username.trim()) {
      newErrors.account_username = 'Account username is required';
    }
    if (!formData.account_password.trim()) {
      newErrors.account_password = 'Account password is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep2 = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.card_number.trim() || formData.card_number.length < 16) {
      newErrors.card_number = 'Valid card number is required';
    }
    if (!formData.expiry_date.trim() || !/^\d{2}\/\d{2}$/.test(formData.expiry_date)) {
      newErrors.expiry_date = 'Valid expiry date (MM/YY) is required';
    }
    if (!formData.cvv.trim() || formData.cvv.length < 3) {
      newErrors.cvv = 'Valid CVV is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNextStep = () => {
    if (currentStep === 1 && validateStep1()) {
      setCurrentStep(2);
    }
  };

  const handleSubmitAccount = async () => {
    if (!validateStep2() || !user) return;

    try {
      await linkedAccountService.createLinkedAccount(user.id, formData);
      Alert.alert(
        'Success',
        'Thanks! Your bank information is under review. You\'ll get an email once it\'s verified.',
        [
          {
            text: 'OK',
            onPress: () => {
              setShowForm(false);
              setCurrentStep(1);
              setFormData({
                bank_name: '',
                account_type: 'checking',
                account_username: '',
                account_password: '',
                card_number: '',
                expiry_date: '',
                cvv: '',
              });
              loadLinkedAccounts();
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error creating linked account:', error);
      Alert.alert('Error', 'Failed to add account. Please try again.');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified':
        return currentColors.success;
      case 'pending':
        return currentColors.warning;
      case 'failed':
        return currentColors.error;
      default:
        return currentColors.textLight;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return 'checkmark-circle';
      case 'pending':
        return 'time';
      case 'failed':
        return 'close-circle';
      default:
        return 'help-circle';
    }
  };

  const renderAccountForm = () => (
    <KeyboardAwareScrollView style={[styles.formContainer, { backgroundColor: currentColors.background }]}>
      <View style={styles.stepIndicator}>
        {[1, 2].map((step) => (
          <View
            key={step}
            style={[
              styles.stepDot,
              step <= currentStep ? styles.stepActive : styles.stepInactive,
              { backgroundColor: step <= currentStep ? currentColors.primary : currentColors.border }
            ]}
          />
        ))}
      </View>

      {currentStep === 1 ? (
        <>
          <Text style={[styles.stepTitle, { color: currentColors.text }]}>Account Information</Text>
          
          <Text style={[commonStyles.text, { color: currentColors.text, textAlign: 'left', marginBottom: 8 }]}>
            Account Type
          </Text>
          <View style={{ flexDirection: 'row', marginBottom: 16 }}>
            <TouchableOpacity
              style={[
                commonStyles.input,
                { 
                  flex: 1, 
                  marginRight: 8, 
                  backgroundColor: formData.account_type === 'checking' ? currentColors.primary : currentColors.backgroundAlt,
                  borderColor: formData.account_type === 'checking' ? currentColors.primary : currentColors.border
                }
              ]}
              onPress={() => handleInputChange('account_type', 'checking')}
            >
              <Text style={{ 
                color: formData.account_type === 'checking' ? currentColors.backgroundAlt : currentColors.text,
                textAlign: 'center'
              }}>
                Checking
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                commonStyles.input,
                { 
                  flex: 1, 
                  marginLeft: 8,
                  backgroundColor: formData.account_type === 'savings' ? currentColors.primary : currentColors.backgroundAlt,
                  borderColor: formData.account_type === 'savings' ? currentColors.primary : currentColors.border
                }
              ]}
              onPress={() => handleInputChange('account_type', 'savings')}
            >
              <Text style={{ 
                color: formData.account_type === 'savings' ? currentColors.backgroundAlt : currentColors.text,
                textAlign: 'center'
              }}>
                Savings
              </Text>
            </TouchableOpacity>
          </View>

          <TextInput
            style={[
              commonStyles.input,
              { backgroundColor: currentColors.backgroundAlt, borderColor: currentColors.border, color: currentColors.text },
              errors.bank_name && { borderColor: currentColors.error }
            ]}
            placeholder="Bank Name"
            placeholderTextColor={currentColors.textLight}
            value={formData.bank_name}
            onChangeText={(value) => handleInputChange('bank_name', value)}
          />
          {errors.bank_name && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.bank_name}</Text>}

          <TextInput
            style={[
              commonStyles.input,
              { backgroundColor: currentColors.backgroundAlt, borderColor: currentColors.border, color: currentColors.text },
              errors.account_username && { borderColor: currentColors.error }
            ]}
            placeholder="Account Username"
            placeholderTextColor={currentColors.textLight}
            value={formData.account_username}
            onChangeText={(value) => handleInputChange('account_username', value)}
          />
          {errors.account_username && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.account_username}</Text>}

          <TextInput
            style={[
              commonStyles.input,
              { backgroundColor: currentColors.backgroundAlt, borderColor: currentColors.border, color: currentColors.text },
              errors.account_password && { borderColor: currentColors.error }
            ]}
            placeholder="Account Password"
            placeholderTextColor={currentColors.textLight}
            value={formData.account_password}
            onChangeText={(value) => handleInputChange('account_password', value)}
            secureTextEntry
          />
          {errors.account_password && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.account_password}</Text>}

          <View style={styles.buttonRow}>
            <Button
              text="Cancel"
              onPress={() => setShowForm(false)}
              variant="outline"
              style={styles.halfButton}
            />
            <Button
              text="Next"
              onPress={handleNextStep}
              style={styles.halfButton}
            />
          </View>
        </>
      ) : (
        <>
          <Text style={[styles.stepTitle, { color: currentColors.text }]}>Card Information</Text>
          
          <TextInput
            style={[
              commonStyles.input,
              { backgroundColor: currentColors.backgroundAlt, borderColor: currentColors.border, color: currentColors.text },
              errors.card_number && { borderColor: currentColors.error }
            ]}
            placeholder="Card Number"
            placeholderTextColor={currentColors.textLight}
            value={formData.card_number}
            onChangeText={(value) => handleInputChange('card_number', value.replace(/\D/g, '').slice(0, 16))}
            keyboardType="numeric"
          />
          {errors.card_number && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.card_number}</Text>}

          <View style={{ flexDirection: 'row' }}>
            <TextInput
              style={[
                commonStyles.input,
                { 
                  flex: 1, 
                  marginRight: 8,
                  backgroundColor: currentColors.backgroundAlt, 
                  borderColor: currentColors.border, 
                  color: currentColors.text 
                },
                errors.expiry_date && { borderColor: currentColors.error }
              ]}
              placeholder="MM/YY"
              placeholderTextColor={currentColors.textLight}
              value={formData.expiry_date}
              onChangeText={(value) => {
                let formatted = value.replace(/\D/g, '');
                if (formatted.length >= 2) {
                  formatted = formatted.slice(0, 2) + '/' + formatted.slice(2, 4);
                }
                handleInputChange('expiry_date', formatted);
              }}
              keyboardType="numeric"
              maxLength={5}
            />
            <TextInput
              style={[
                commonStyles.input,
                { 
                  flex: 1, 
                  marginLeft: 8,
                  backgroundColor: currentColors.backgroundAlt, 
                  borderColor: currentColors.border, 
                  color: currentColors.text 
                },
                errors.cvv && { borderColor: currentColors.error }
              ]}
              placeholder="CVV"
              placeholderTextColor={currentColors.textLight}
              value={formData.cvv}
              onChangeText={(value) => handleInputChange('cvv', value.replace(/\D/g, '').slice(0, 4))}
              keyboardType="numeric"
              secureTextEntry
            />
          </View>
          {errors.expiry_date && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.expiry_date}</Text>}
          {errors.cvv && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.cvv}</Text>}

          <View style={styles.buttonRow}>
            <Button
              text="Back"
              onPress={() => setCurrentStep(1)}
              variant="outline"
              style={styles.halfButton}
            />
            <Button
              text="Submit"
              onPress={handleSubmitAccount}
              style={styles.halfButton}
            />
          </View>
        </>
      )}
    </KeyboardAwareScrollView>
  );

  if (showForm) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
        <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
          <TouchableOpacity onPress={() => setShowForm(false)}>
            <Icon name="arrow-back" size={24} color={currentColors.text} />
          </TouchableOpacity>
          <Text style={[styles.title, { color: currentColors.text }]}>Add Account</Text>
          <View style={{ width: 24 }} />
        </View>
        {renderAccountForm()}
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Linked Accounts</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView style={{ flex: 1 }}>
        {loading ? (
          <View style={styles.emptyState}>
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>Loading accounts...</Text>
          </View>
        ) : linkedAccounts.length === 0 ? (
          <View style={styles.emptyState}>
            <Icon name="card-outline" size={64} color={currentColors.textLight} />
            <Text style={[styles.emptyText, { color: currentColors.textLight }]}>No linked accounts</Text>
            <Text style={[styles.emptyText, { color: currentColors.textLight, fontSize: 14 }]}>
              Add a bank account to start making withdrawals
            </Text>
          </View>
        ) : (
          linkedAccounts.map((account) => (
            <View key={account.id} style={[styles.accountCard, { backgroundColor: currentColors.card, borderColor: currentColors.border }]}>
              <View style={styles.accountInfo}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.bankName, { color: currentColors.text }]}>{account.bank_name}</Text>
                  <Text style={[styles.accountDetails, { color: currentColors.textLight }]}>
                    {account.account_type.charAt(0).toUpperCase() + account.account_type.slice(1)} •••• {account.last_four_digits}
                  </Text>
                </View>
                <View style={[styles.statusBadge, { backgroundColor: getStatusColor(account.status) + '20' }]}>
                  <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                    <Icon name={getStatusIcon(account.status)} size={16} color={getStatusColor(account.status)} />
                    <Text style={[styles.statusText, { color: getStatusColor(account.status), marginLeft: 4 }]}>
                      {account.status.charAt(0).toUpperCase() + account.status.slice(1)}
                    </Text>
                  </View>
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>

      <View style={styles.addButton}>
        <Button
          text="Add New Account"
          onPress={() => setShowForm(true)}
        />
      </View>
    </SafeAreaView>
  );
};

export default LinkedAccountsScreen;