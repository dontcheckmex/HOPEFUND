import { commonStyles, colors } from '../styles/commonStyles';
import { SafeAreaView } from 'react-native-safe-area-context';
import { View, Text, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import Icon from '../components/Icon';
import React, { useState } from 'react';
import { DrawerActions } from '@react-navigation/native';
import { useAuth } from './context/AuthContext';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import Button from '../components/Button';
import { supportService } from './integrations/supabase/services';
import { router } from 'expo-router';
import { useTheme } from './context/ThemeContext';

interface FAQItem {
  question: string;
  answer: string;
}

const styles = {
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '700' as const,
    textAlign: 'center' as const,
  },
  section: {
    backgroundColor: colors.card,
    borderRadius: 16,
    margin: 20,
    overflow: 'hidden' as const,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700' as const,
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  formContainer: {
    padding: 20,
  },
  fieldLabel: {
    fontSize: 16,
    fontWeight: '500' as const,
    marginBottom: 8,
  },
  textArea: {
    minHeight: 120,
    textAlignVertical: 'top' as const,
  },
  faqItem: {
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  faqQuestion: {
    flexDirection: 'row' as const,
    justifyContent: 'space-between' as const,
    alignItems: 'center' as const,
    padding: 20,
  },
  faqQuestionText: {
    fontSize: 16,
    fontWeight: '500' as const,
    flex: 1,
    marginRight: 12,
  },
  faqAnswer: {
    padding: 20,
    paddingTop: 0,
  },
  faqAnswerText: {
    fontSize: 14,
    lineHeight: 20,
    color: colors.textLight,
  },
  submitButton: {
    marginTop: 24,
  },
};

const SupportScreen: React.FC = () => {
  const navigation = useNavigation();
  const { user } = useAuth();
  const { currentColors } = useTheme();
  const [formData, setFormData] = useState({
    name: user?.full_name || '',
    email: user?.email || '',
    message: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const faqData: FAQItem[] = [
    {
      question: 'How do I sign up?',
      answer: 'To sign up, click the "Sign Up" button on the main page and fill out the required information including your full name, email, username, phone number, and password. After successful registration, you\'ll receive a $25 sign-up bonus!'
    },
    {
      question: 'What\'s the minimum withdrawal?',
      answer: 'The minimum withdrawal amount is $10. You can withdraw up to $100,000 per transaction, subject to your available balance.'
    },
    {
      question: 'Why is my linked account pending?',
      answer: 'New linked accounts require verification for security purposes. This process typically takes 1-3 business days. You\'ll receive an email notification once your account is verified and ready for withdrawals.'
    },
    {
      question: 'How long do withdrawals take?',
      answer: 'Withdrawals are typically processed within 1-3 business days. The exact timing depends on your bank and the withdrawal method. You\'ll see the status update in your transaction history.'
    },
    {
      question: 'Can I change my email?',
      answer: 'Currently, email changes must be requested through our support team. Please contact us using the form below with your current email and the new email address you\'d like to use.'
    }
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (!formData.message.trim()) {
      newErrors.message = 'Message is required';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters long';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmitContact = async () => {
    if (!validateForm()) return;

    try {
      setSubmitting(true);
      
      await supportService.createSupportTicket({
        user_id: user?.id,
        name: formData.name,
        email: formData.email,
        message: formData.message,
      });

      Alert.alert(
        'Message Sent',
        'Thank you for contacting us! We\'ll get back to you within 24 hours.',
        [
          {
            text: 'OK',
            onPress: () => {
              setFormData({
                name: user?.full_name || '',
                email: user?.email || '',
                message: '',
              });
            }
          }
        ]
      );
    } catch (error) {
      console.error('Error submitting support ticket:', error);
      Alert.alert('Error', 'Failed to send message. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  const getInputStyle = (fieldName: string) => [
    commonStyles.input,
    {
      backgroundColor: currentColors.backgroundAlt,
      borderColor: currentColors.border,
      color: currentColors.text,
    },
    errors[fieldName] && { borderColor: currentColors.error }
  ];

  const renderContactForm = () => (
    <View style={[styles.section, { backgroundColor: currentColors.card }]}>
      <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border }]}>
        Contact Support
      </Text>
      <View style={styles.formContainer}>
        <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Name</Text>
        <TextInput
          style={getInputStyle('name')}
          placeholder="Your full name"
          placeholderTextColor={currentColors.textLight}
          value={formData.name}
          onChangeText={(value) => handleInputChange('name', value)}
        />
        {errors.name && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.name}</Text>}

        <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Email</Text>
        <TextInput
          style={getInputStyle('email')}
          placeholder="your.email@example.com"
          placeholderTextColor={currentColors.textLight}
          value={formData.email}
          onChangeText={(value) => handleInputChange('email', value)}
          keyboardType="email-address"
          autoCapitalize="none"
        />
        {errors.email && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.email}</Text>}

        <Text style={[styles.fieldLabel, { color: currentColors.text }]}>Message</Text>
        <TextInput
          style={[getInputStyle('message'), styles.textArea]}
          placeholder="Describe your issue or question..."
          placeholderTextColor={currentColors.textLight}
          value={formData.message}
          onChangeText={(value) => handleInputChange('message', value)}
          multiline
          numberOfLines={6}
        />
        {errors.message && <Text style={[commonStyles.errorText, { color: currentColors.error }]}>{errors.message}</Text>}

        <Button
          text={submitting ? "Sending..." : "Send Message"}
          onPress={handleSubmitContact}
          disabled={submitting}
          style={styles.submitButton}
        />
      </View>
    </View>
  );

  const renderFAQ = () => (
    <View style={[styles.section, { backgroundColor: currentColors.card }]}>
      <Text style={[styles.sectionTitle, { color: currentColors.text, borderBottomColor: currentColors.border }]}>
        Frequently Asked Questions
      </Text>
      {faqData.map((item, index) => (
        <View key={index} style={[styles.faqItem, { borderBottomColor: currentColors.border }]}>
          <TouchableOpacity
            style={styles.faqQuestion}
            onPress={() => toggleFAQ(index)}
          >
            <Text style={[styles.faqQuestionText, { color: currentColors.text }]}>
              {item.question}
            </Text>
            <Icon
              name={expandedFAQ === index ? "chevron-up" : "chevron-down"}
              size={20}
              color={currentColors.textLight}
            />
          </TouchableOpacity>
          {expandedFAQ === index && (
            <View style={styles.faqAnswer}>
              <Text style={[styles.faqAnswerText, { color: currentColors.textLight }]}>
                {item.answer}
              </Text>
            </View>
          )}
        </View>
      ))}
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: currentColors.background }]}>
      <View style={[styles.header, { borderBottomColor: currentColors.border, backgroundColor: currentColors.backgroundAlt }]}>
        <TouchableOpacity onPress={() => navigation.dispatch(DrawerActions.openDrawer())}>
          <Icon name="menu" size={24} color={currentColors.primary} />
        </TouchableOpacity>
        <Text style={[styles.title, { color: currentColors.text }]}>Support</Text>
        <View style={{ width: 24 }} />
      </View>

      <KeyboardAwareScrollView style={{ flex: 1 }}>
        {renderContactForm()}
        {renderFAQ()}
      </KeyboardAwareScrollView>
    </SafeAreaView>
  );
};

export default SupportScreen;